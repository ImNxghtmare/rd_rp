#version 330

// Vanilla 1.21.11 startup shaders cannot use moj_import.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;
noperspective out vec2 dialogPosition;
noperspective out vec2 dialogQuadUv;
flat out vec2 dialogScreenSize;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexColor = Color;

    // ColoredRectangleRenderState emits TL, BL, BR, TR. Minecraft's sequential
    // quad index buffer uses 0,1,2 / 2,3,0, including batched base-vertex offsets.
    int corner = gl_VertexID & 3;
    dialogQuadUv = vec2(corner >= 2 ? 1.0 : 0.0,
                        corner == 1 || corner == 2 ? 1.0 : 0.0);
    dialogScreenSize = vec2(0.0);
    if (ProjMat[3][3] == 1.0 && ProjMat[0][0] > 0.0 && ProjMat[1][1] < 0.0
            && ProjMat[3][0] == -1.0 && ProjMat[3][1] == 1.0
            && ProjMat[0][1] == 0.0 && ProjMat[1][0] == 0.0) {
        // Projection uses physicalSize / guiScale; Screen.width/height use ceil.
        // The epsilon removes float reciprocal noise at exact integer sizes.
        dialogScreenSize = ceil(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) - 0.001);
    }
    // Keep derivative operands near zero: absolute screen coordinates otherwise
    // lose enough precision at GUI scale 3 to distort reconstructed edge widths.
    dialogPosition = Position.xy - vec2(dialogScreenSize.x * 0.5, 160.0);
}

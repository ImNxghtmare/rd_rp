#version 330

#moj_import <minecraft:globals.glsl>

layout(std140) uniform SamplerInfo {
vec2 OutSize;
};

in vec2 texCoord;

out vec4 fragColor;

ivec3 ov_texel(sampler2D s, int x) { return ivec3(round(texelFetch(s, ivec2(x, 0), 0).rgb * 255.0)); }

// An overlay's signature in [s]'s four bottom-left texels (text.fsh, mcb_signature): its flags plus 8, or 0
// without one; [tint], the view's tint.
int ov_signature(sampler2D s, out vec4 tint) {
tint = vec4(0.0);
ivec3 c0 = ov_texel(s, 0), c3 = ov_texel(s, 3);
if (c0 != ivec3(90, 195, 150) || c3 != ivec3(0, 0, 105)) return 0;
ivec3 c1 = ov_texel(s, 1), c2 = ov_texel(s, 2);
tint = vec4(vec3(c1), float(c2.r)) / 255.0;
return c2.g | 8;
}
layout(std140) uniform OverlayHold1 {
float Hold1;
};

layout(std140) uniform OverlayHold2 {
float Hold2;
};

uniform sampler2D InSampler;

void main() {
vec4 tint;
if (ov_signature(InSampler, tint) == 0 || Hold1 + Hold2 + GameTime + OutSize.x < -1.0) discard;
fragColor = vec4(0.0);
}

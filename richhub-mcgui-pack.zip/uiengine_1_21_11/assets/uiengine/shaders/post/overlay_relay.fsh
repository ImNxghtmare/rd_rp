#version 330

#moj_import <minecraft:globals.glsl>

layout(std140) uniform SamplerInfo {
vec2 OutSize;
};

in vec2 texCoord;

out vec4 fragColor;

ivec3 ov_texel(sampler2D s, int x) { return ivec3(round(texelFetch(s, ivec2(x, 0), 0).rgb * 255.0)); }

// An overlay's signature in [s]'s four bottom-left texels (text.fsh, mcb_signature): its flags plus 8, or 0
// without one; [tint], the view's tint.
int ov_signature(sampler2D s, out vec4 tint) {
tint = vec4(0.0);
ivec3 c0 = ov_texel(s, 0), c3 = ov_texel(s, 3);
if (c0 != ivec3(90, 195, 150) || c3 != ivec3(0, 0, 105)) return 0;
ivec3 c1 = ov_texel(s, 1), c2 = ov_texel(s, 2);
tint = vec4(vec3(c1), float(c2.r)) / 255.0;
return c2.g | 8;
}
uniform sampler2D MainSampler;

ivec3 ov_relayed(sampler2D s, int i) {
return ivec3(round(vec3(texelFetch(s, ivec2(3 * i, 0), 0).a, texelFetch(s, ivec2(3 * i + 1, 0), 0).a,
texelFetch(s, ivec2(3 * i + 2, 0), 0).a) * 255.0));
}

bool ov_relay_signed(sampler2D s) {
return ov_relayed(s, 0) == ivec3(90, 195, 150) && ov_relayed(s, 3) == ivec3(0, 0, 105);
}

void main() {
ivec2 at = ivec2(gl_FragCoord.xy);
if (at.y != 0 || at.x >= 4 || !ov_relay_signed(MainSampler)) discard;
fragColor = vec4(vec3(ov_relayed(MainSampler, at.x)) / 255.0, 1.0);
}

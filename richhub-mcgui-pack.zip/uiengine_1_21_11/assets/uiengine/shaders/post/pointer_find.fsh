#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
vec2 OutSize;
};

in vec2 texCoord;

out vec4 fragColor;

ivec3 mcb_code(ivec2 p) {
uint h = uint(p.x) * 0x9E3779B1u ^ uint(p.y) * 0x85EBCA77u;
h ^= h >> 15;
h *= 0x2C1B3C6Du;
h ^= h >> 12;
int e = int(h >> 26);
return ivec3(e & 3, (e >> 2) & 3, (e >> 4) & 3);
}

bool coded(ivec2 p) {
return (ivec3(round(texelFetch(InSampler, p, 0).rgb * 255.0)) & 3) == mcb_code(p);
}

void main() {
ivec2 at = ivec2(gl_FragCoord.xy);
vec3 here = texelFetch(InSampler, at, 0).rgb;
bool pointer = false;
if (coded(at)) {
ivec2 edge = textureSize(InSampler, 0) - 1;
int near = 0;
for (int i = 0; i < 9; i++) {
ivec2 q = at + ivec2(i % 3 - 1, i / 3 - 1);
if (i != 4 && q == clamp(q, ivec2(0), edge) && coded(q)) near++;
}
pointer = near >= 2;
}
fragColor = vec4(here, pointer ? 1.0 : 0.0);
}

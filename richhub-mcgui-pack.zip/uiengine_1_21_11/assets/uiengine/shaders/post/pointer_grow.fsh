#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
vec2 OutSize;
};

in vec2 texCoord;

out vec4 fragColor;

void main() {
ivec2 at = ivec2(gl_FragCoord.xy);
ivec2 edge = textureSize(InSampler, 0) - 1;
float near = 0.0;
for (int i = 0; i < 25; i++) {
near = max(near, texelFetch(InSampler, clamp(at + ivec2(i % 5 - 2, i / 5 - 2), ivec2(0), edge), 0).a);
}
fragColor = vec4(texelFetch(InSampler, at, 0).rgb, near);
}

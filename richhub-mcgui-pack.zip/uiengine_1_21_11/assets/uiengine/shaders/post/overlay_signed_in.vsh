#version 330

out vec2 texCoord;

ivec3 ov_texel(sampler2D s, int x) { return ivec3(round(texelFetch(s, ivec2(x, 0), 0).rgb * 255.0)); }

// An overlay's signature in [s]'s four bottom-left texels (text.fsh, mcb_signature): its flags plus 8, or 0
// without one; [tint], the view's tint.
int ov_signature(sampler2D s, out vec4 tint) {
tint = vec4(0.0);
ivec3 c0 = ov_texel(s, 0), c3 = ov_texel(s, 3);
if (c0 != ivec3(90, 195, 150) || c3 != ivec3(0, 0, 105)) return 0;
ivec3 c1 = ov_texel(s, 1), c2 = ov_texel(s, 2);
tint = vec4(vec3(c1), float(c2.r)) / 255.0;
return c2.g | 8;
}

vec2 ov_uv() {
vec2 uv = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
texCoord = uv;
return uv;
}

void ov_window(vec2 uv) { gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0); }

// Legs two pixels long: the bottom-left pixel's centre is well inside, and nothing else's but along an edge.
void ov_corner(vec2 uv, vec2 size) { gl_Position = vec4(uv * 2.0 / size - 1.0, 0.0, 1.0); }

// Every corner at one point, off the window: no fragment at all.
void ov_none() { gl_Position = vec4(-2.0, -2.0, 0.0, 1.0); }

uniform sampler2D InSampler;

void main() {
vec2 uv = ov_uv();
vec4 tint;
if (ov_signature(InSampler, tint) == 0) ov_none();
else ov_window(uv);
}

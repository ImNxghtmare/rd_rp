#version 330

#moj_import <minecraft:globals.glsl>

layout(std140) uniform SamplerInfo {
vec2 OutSize;
};

in vec2 texCoord;

out vec4 fragColor;

ivec3 ov_texel(sampler2D s, int x) { return ivec3(round(texelFetch(s, ivec2(x, 0), 0).rgb * 255.0)); }

// An overlay's signature in [s]'s four bottom-left texels (text.fsh, mcb_signature): its flags plus 8, or 0
// without one; [tint], the view's tint.
int ov_signature(sampler2D s, out vec4 tint) {
tint = vec4(0.0);
ivec3 c0 = ov_texel(s, 0), c3 = ov_texel(s, 3);
if (c0 != ivec3(90, 195, 150) || c3 != ivec3(0, 0, 105)) return 0;
ivec3 c1 = ov_texel(s, 1), c2 = ov_texel(s, 2);
tint = vec4(vec3(c1), float(c2.r)) / 255.0;
return c2.g | 8;
}
uniform sampler2D InSampler;
uniform sampler2D KeptSampler;

layout(std140) uniform OverlayConfig {
vec2 BlurDir;
float Last;
};

vec3 ov_world(ivec2 p, bool signature) {
if (signature && p.y == 0 && p.x < 4) p.y = 1;
return texelFetch(InSampler, p, 0).rgb;
}

vec3 ov_blurred(ivec2 at, bool blur, bool signature) {
if (!blur) return ov_world(at, signature);
ivec2 dir = ivec2(BlurDir);
ivec2 edge = textureSize(InSampler, 0) - 1;
vec3 sum = vec3(0.0);
for (int k = -MenuBlurRadius; k <= MenuBlurRadius; k++) sum += ov_world(clamp(at + dir * k, ivec2(0), edge), signature);
return sum / float(2 * MenuBlurRadius + 1);
}

void main() {
ivec2 at = ivec2(gl_FragCoord.xy);
vec4 tint;
int flags = ov_signature(InSampler, tint);
if (flags == 0) discard;
// A new window size drops the kept picture: its alpha is 0 until one is kept again.
bool take = (flags & 2) == 0 || texelFetch(KeptSampler, ivec2(0), 0).a < 0.5;
if (!take) {
if (at != ivec2(0)) discard;
fragColor = vec4(0.0);
return;
}
fragColor = vec4(ov_blurred(at, (flags & 1) != 0, true), 1.0);
}

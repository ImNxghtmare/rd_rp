#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

// rpai-merge:begin fragment-declarations v1
// rpai-merge:end fragment-declarations
void mcgui_text_fragment() {
#ifdef IS_GRAYSCALE
vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
vec4 color = texColor * vertexColor;
#else
vec4 color = texColor * vertexColor * ColorModulator;
#endif
if (color.a < 0.1) {
discard;
}

#ifdef IS_SEE_THROUGH
fragColor = color * ColorModulator;
#elif defined(IS_GUI)
fragColor = color;
#else
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
// rpai-merge:begin fragment-vanilla v1
// #moj_import <minecraft:dynamictransforms.glsl>
// uniform sampler2D Sampler0;
// in vec4 vertexColor;
// in vec2 texCoord0;
// out vec4 fragColor;
// rpai-merge:end fragment-vanilla
// rpai-merge:begin fragment-epilogue v1
// rpai-merge:renames main mcgui_text_fragment

// ---- MC GUI hi-colour map decoder ----
// Colour -> symbol: the palette gives each symbol the colour that hashes to it (SymbolHash), so the hash
// is the whole lookup: a displacement for one of 64 buckets (128 for an odd palette), bytes four to a
// uint, read with selects alone. Never a table read by a computed index: AMD's Windows OpenGL driver
// turns one into seconds a frame and minutes of compiling (Mr Crash's RX 7700 XT, 2026-11-03: 2 FPS
// with the old table, 119 without).
uint mcb_displacements(uint i) {
uvec4 t0_0 = (i & 8u) != 0u ? uvec4(391774590u, 1662151960u, 339798529u, 53280883u) : uvec4(906494208u, 342563082u, 67249448u, 161304064u);
uvec4 t0_1 = (i & 8u) != 0u ? uvec4(2843839628u, 2316404752u, 679716608u, 3477053313u) : uvec4(25034762u, 2349278011u, 118704130u, 203165200u);
uvec4 t1_0 = (i & 4u) != 0u ? t0_1 : t0_0;
uvec2 h = (i & 2u) != 0u ? t1_0.zw : t1_0.xy;
return (i & 1u) != 0u ? h.y : h.x;
}

int mcb_symbol_of(vec3 rgb) {
uvec3 c = uvec3(round(rgb * 255.0));
uint k = (c.r << 16u) | (c.g << 8u) | c.b;
uint b = (k * 1372926309u) >> 26u;
uint s = (((k * 3137834733u) >> 24u) * 240u >> 8u) + ((mcb_displacements(b >> 2u) >> ((b & 3u) << 3u)) & 255u);
return int(s >= 240u ? s - 240u : s);
}

// Where the map being read starts in Sampler0: (0, 0) unless the texture holds many maps (mcb_texture).
ivec2 mcbBase = ivec2(0);

ivec3 mcb_fetch(ivec2 p) { return ivec3(round(texelFetch(Sampler0, mcbBase + p, 0).rgb * 255.0)); }

int mcb_symbol(ivec2 p) { return mcb_symbol_of(texelFetch(Sampler0, mcbBase + p, 0).rgb); }

// The symbols of the 2x2 block whose top-left pixel is [p] and has colour [first].
ivec4 mcb_symbols(ivec2 p, vec3 first) {
return ivec4(mcb_symbol_of(first), mcb_symbol(p + ivec2(1, 0)), mcb_symbol(p + ivec2(0, 1)), mcb_symbol(p + ivec2(1, 1)));
}

// 1 if Sampler0 is one map's own texture, 2 if it could hold many 128 x 128 maps side by side (ImmediatelyFast's
// map atlas, 2048 square by default, but a font page of 256 or 1024 is as square), 0 if it holds none.
int mcb_texture() {
ivec2 size = textureSize(Sampler0, 0);
if (size == ivec2(128, 128)) return 1;
return size.x == size.y && size.x >= 256 && (size.x & 127) == 0 ? 2 : 0;
}

bool mcb_in_texture(ivec2 base, ivec2 size) { return all(greaterThanEqual(base, ivec2(0))) && all(lessThan(base, size)); }

// Which of ours the map at mcbBase is. 0: not ours. 1: a screen. 3: the view of whoever is seated at it, each
// map carrying its place (bottom markers both the fourth). text.vsh then tells two kinds of 3 apart for
// text.fsh: 5, an overlay's signature map, and 6, a map of an overlay's panel. 7: a hover layer of a view
// (Palette.markLayer): top markers swapped too. Only for a texture mcb_texture says can hold maps.
int mcb_screen_map() {
ivec3 m0 = mcb_fetch(ivec2(0, 0)), m1 = mcb_fetch(ivec2(1, 0));
bool layer = m0 == ivec3(109,144,129) && m1 == ivec3(89,117,105);
if (!layer && (m0 != ivec3(89,117,105) || m1 != ivec3(109,144,129))) return 0;
ivec3 a = mcb_fetch(ivec2(0, 1));
ivec3 b = mcb_fetch(ivec2(1, 1));
if (layer) return a == ivec3(67,88,79) && b == ivec3(67,88,79) ? 7 : 0;
if (a == ivec3(127,167,150) && b == ivec3(67,88,79)) return 1;
if (a == ivec3(67,88,79) && b == ivec3(67,88,79)) return 3;
return 0;
}

// What someone's own view lays over the world where it is transparent (Palette.markTint): red,
// green, blue and alpha in the 2x2 block after its size.
vec4 mcb_tint() {
return vec4(float(mcb_symbol(ivec2(4, 0))), float(mcb_symbol(ivec2(5, 0))),
float(mcb_symbol(ivec2(4, 1))), float(mcb_symbol(ivec2(5, 1)))) / 239.0;
}

// How many 2x2 blocks after the marker hold data, not picture: a view's size, place and tint (2); a
// hover layer's size, place, speed, flags and two rectangles (7, the top two rows, never shown).
int mcb_info(int kind) { return kind == 7 ? 7 : kind >= 2 ? 2 : 0; }

// A 2x2 block's mean luma and its chroma, and 1 (0 for all four when it is transparent).
vec4 mcb_block(ivec2 b) {
ivec2 p = b * 2;
vec4 c00 = texelFetch(Sampler0, mcbBase + p, 0);
if (c00.a < 0.5) return vec4(0.0);
ivec4 s = mcb_symbols(p, c00.rgb);
ivec4 digit = s & 7;
return vec4(dot(vec4(s >> 3), vec4(0.25)) / 29.0, float(digit.x * 8 + digit.y - 32) / 63.0,
float(digit.z * 8 + digit.w - 32) / 63.0, 1.0);
}

// 1 if a map's data blocks (row 0, up to block [info]) are best shown as the block right of them, 0 if as
// the blocks below them: right when an edge runs between the top two block rows just past the data, so
// likely through the data too, below otherwise (nearer, and right for anything that changes along the
// row). Measured on the market pages' maps, this halves how often the fill differs visibly from the
// picture it covers, against always right or always below.
float mcb_fill_right(int info) {
vec4 a = mcb_block(ivec2(info + 1, 0)), b = mcb_block(ivec2(info + 1, 1));
if (a.w != b.w) return 1.0;
vec4 d = abs(a - b);
return d.x + 0.5 * (d.y + d.z) > 0.06 ? 1.0 : 0.0;
}

ivec3 mcb_code(ivec2 p) {
uint h = uint(p.x) * 0x9E3779B1u ^ uint(p.y) * 0x85EBCA77u;
h ^= h >> 15;
h *= 0x2C1B3C6Du;
h ^= h >> 12;
int e = int(h >> 26);
return ivec3(e & 3, (e >> 2) & 3, (e >> 4) & 3);
}

vec3 mcb_pointer_code(vec3 rgb) {
ivec3 c = ivec3(round(clamp(rgb, 0.0, 1.0) * 255.0));
return vec3((c & ~3) | mcb_code(ivec2(gl_FragCoord.xy))) / 255.0;
}

// The screen is almost never drawn at one map pixel per window pixel. Instead of the
// nearest pixel (uneven, shimmering text), average the map pixels under this window
// pixel's footprint, weighted by overlap. Averaging in YCbCr is exact: the conversion to
// RGB is linear. Pixels come in 2x2 blocks that share one chroma value; a footprint at most
// two pixels across touches at most 2x2 of them. The first [info] + 1 blocks of the top row
// hold data, not picture (the marker, a view's size and place, its tint, a blurred view's
// panel): they show the block right of them, or each the block below it, as [fillRight] says
// (mcb_fill_right). A transparent block (map colours 0-3, alpha 0) adds no colour: alpha is how
// much of the footprint the opaque blocks cover, so a picture's edge against the world is smooth.
vec4 mcb_sample(vec2 t, vec2 fw, int info, bool fillRight) {
vec2 halfFw = clamp(fw, vec2(0.02), vec2(2.0)) * 0.5;
vec2 lo = clamp(t - halfFw, vec2(0.0), vec2(128.0));
vec2 hi = clamp(t + halfFw, vec2(0.0), vec2(128.0));
ivec2 b0 = clamp(ivec2(floor(lo * 0.5)), ivec2(0), ivec2(63));
ivec2 b1 = clamp(ivec2(floor((hi - 0.0001) * 0.5)), ivec2(0), ivec2(63));
vec3 acc = vec3(0.0);
float total = 0.0;
float covered = 0.0;
for (int i = 0; i < 4; i++) {
ivec2 b = b0 + ivec2(i & 1, i >> 1);
if (b.x > b1.x || b.y > b1.y) continue;
ivec2 base = b * 2;
vec2 p0 = vec2(base);
vec2 ov0 = max(min(hi, p0 + 1.0) - max(lo, p0), 0.0);
vec2 ov1 = max(min(hi, p0 + 2.0) - max(lo, p0 + 1.0), 0.0);
vec4 w = vec4(ov0.x * ov0.y, ov1.x * ov0.y, ov0.x * ov1.y, ov1.x * ov1.y);
float ws = w.x + w.y + w.z + w.w;
total += ws;
ivec2 src = b.y > 0 || b.x > info ? base : fillRight ? ivec2(2 * info + 2, 0) : ivec2(base.x, 2);
vec4 c00 = texelFetch(Sampler0, mcbBase + src, 0);
if (c00.a < 0.5) continue;
ivec4 s = mcb_symbols(src, c00.rgb);
vec4 luma = vec4(s >> 3) / 29.0;
ivec4 digit = s & 7;
vec2 chroma = vec2(float(digit.x * 8 + digit.y - 32), float(digit.z * 8 + digit.w - 32)) / 63.0;
acc += vec3(dot(w, luma), chroma * ws);
covered += ws;
}
if (covered <= 0.0) return vec4(0.0);
vec3 ycc = acc / covered;
return vec4(clamp(vec3(ycc.x + 1.402 * ycc.z, ycc.x - 0.344136 * ycc.y - 0.714136 * ycc.z, ycc.x + 1.772 * ycc.y), 0.0, 1.0),
covered / max(total, 1e-6));
}

// An overlay's signature, for the post effect that keeps the world round its panel (Shaders.overlayChain),
// written as the window's four bottom-left pixels: a check, the view's tint, its alpha and the flags (the
// signature map's own, Palette.markSignature, and whether depth is reversed), and a second check.
vec3 mcb_signature(int i, vec4 tint, bool reversed) {
ivec4 t = ivec4(round(clamp(tint, 0.0, 1.0) * 255.0));
int flags = mcb_symbol(ivec2(6, 0)) | (reversed ? 4 : 0);
ivec3 c = i == 0 ? ivec3(90,195,150) : i == 1 ? t.rgb : i == 2 ? ivec3(t.a, flags, 0) : ivec3(0, 0, 105);
return vec3(c) / 255.0;
}

// Our fragment's colour out, at [depth]: improved transparency's phases (26.3) as vanilla's own, and the
// pointer's code for the menu blur to find it by (menuBlurChain), never in the accumulate pass, whose
// output is a weighted share, not a colour.
void mcb_emit(vec4 c, float depth, bool pointer) {
if (pointer && c.a > 0.99) c.rgb = mcb_pointer_code(c.rgb);
fragColor = c;
}
#ifndef IS_GUI

// Draws this fragment if it is ours and says whether it was: a seated player's pointer or a map of their view
// (both told by text.vsh in vertexColor, Shaders.ENCODED_VIEW), or a map of a wall (found here by its marker,
// whoever's text.vsh ran). Anything else is left to the text shader we were put after.
bool mcb_fragment(vec2 mcbFootprint) {
vec4 code = vertexColor;
if (code.w >= 16.0 - 0.5 && code.w < 65536.0 - 0.5) {
// A seated player's pointer, drawn white, as near as depth goes, in front of the picture and of all else.
int kind = int(floor(code.w / 16.0));
float rest = code.w - 16.0 * float(kind);
bool reversed = rest > 4.0;
float alpha = clamp(rest - (reversed ? 8.0 : 0.0), 0.0, 1.0);
vec4 tex = texture(Sampler0, texCoord0);
// The pointer font is stored faint (Shaders.POINTER_ALPHA), so only this shader shows it.
tex.a = min(1.0, tex.a * 10.6250);
vec4 color = tex * vec4(code.rgb, alpha) * ColorModulator;
if (color.a < 0.1) discard;
float depth = reversed ? 1.0 : 0.0;
gl_FragDepth = depth;
mcb_emit(color, depth, true);
return true;
}
int mcbMap;
bool mcbFill;
int mcbPriority = 0;
bool mcbRev = false;
vec4 mcbViewTint = vec4(0.0);
vec2 mcbScale = vec2(textureSize(Sampler0, 0)) / 128.0;
vec2 mcbTex;
if (code.w >= 65536.0 - 0.5) {
// A map of someone's own view, placed in their window by text.vsh.
int red = int(round(code.r));
int green = int(round(code.g));
int blue = int(round(code.b));
int alpha = int(round(code.w - 65536.0));
mcbMap = red & 7;
mcbFill = (red & 8) != 0;
mcbPriority = (red >> 4) & 63;
mcbRev = (red & 1024) != 0;
mcbBase = ivec2(green % 64, green / 64) * 128;
mcbViewTint = vec4(float(blue >> 8), float(blue & 255), float(alpha >> 8), float(alpha & 255)) / 239.0;
mcbTex = texCoord0 * 128.0 * mcbScale - vec2(mcbBase);
} else {
// Maybe a map on a wall. One map's own texture is 128 x 128; a texture of many (ImmediatelyFast's map
// atlas, or a font page as square) puts each in a 128 x 128 square, found pixel by pixel.
int textureKind = mcb_texture();
if (textureKind == 0) return false;
vec2 mcbAt = texCoord0 * 128.0 * mcbScale;
mcbBase = textureKind == 1 ? ivec2(0) : ivec2(floor(mcbAt / 128.0)) * 128;
if (!mcb_in_texture(mcbBase, textureSize(Sampler0, 0))) return false;
mcbMap = mcb_screen_map();
if (mcbMap == 0) return false;
// A view's map that no vertex shader of ours placed (one not seated, or another text.vsh): pieces of
// the picture where its frame lies, never wanted.
if (mcbMap > 1) discard;
mcbTex = mcbAt - vec2(mcbBase);
// Its marker block shows a neighbour's (mcb_sample), worked out only where that is near.
mcbFill = mcbTex.x < 4.0 && mcbTex.y < 4.0 && mcb_fill_right(0) > 0.5;
}
mcbFootprint *= mcbScale;
vec4 mcbColor;
float mcbDepth = gl_FragCoord.z;
if (mcbMap == 5) {
if (gl_FragCoord.y >= 1.0 || gl_FragCoord.x >= 4.0) discard;
mcbColor = vec4(mcb_signature(int(gl_FragCoord.x), mcbViewTint, mcbRev), 1.0);
} else {
// A hover layer (7) shows only while text.vsh places it, and never its top two rows, its
// data: there, and wherever it is transparent, the view under it shows.
if (mcbMap == 7 && (mcbPriority == 0 || mcbTex.y < 2.0)) discard;
// A screen emits its own light: no lightmap, tint or fog, so colours are exact day and night.
vec4 mcbPicture = mcb_sample(mcbTex, mcbFootprint, mcb_info(mcbMap), mcbMap != 7 && mcbFill);
// An overlay's panel (6) is there or not, never blended with the world behind it: round it the
// post effect shows the world as it was, tinted there. A hover layer likewise over its view.
if (mcbMap >= 6) mcbPicture = mcbPicture.a < 0.5 ? vec4(0.0) : vec4(mcbPicture.rgb, 1.0);
// Where the picture is transparent the world behind shows, on someone's own view under its
// tint: the picture over the tint over the world, as one colour blended over the world.
vec4 mcbTint = mcbMap >= 2 && mcbMap < 6 && mcbPicture.a < 1.0 ? mcbViewTint : vec4(0.0);
float mcbAlpha = 1.0 - (1.0 - mcbPicture.a) * (1.0 - mcbTint.a);
if (mcbAlpha < 0.002) discard;
mcbColor = vec4((mcbPicture.rgb * mcbPicture.a + mcbTint.rgb * (mcbTint.a * (1.0 - mcbPicture.a))) / max(mcbAlpha, 0.002), mcbAlpha);
}
if (mcbMap >= 2) {
// A view (3, 6) is just behind its pointer, in front of all else: its frames are at the
// camera, so its own depth means nothing. A signature (5) is nearest. A hover layer (7) is a
// step or more in front of its view, the higher its priority the nearer, and still behind the
// pointer, whichever is drawn first. No block between the camera and the picture needs clearing.
float mcbStep = mcbMap == 7 ? float(mcbPriority) * 1.2e-7 : 0.0;
mcbDepth = mcbMap == 5 ? (mcbRev ? 1.0 : 0.0) : (mcbRev ? 0.99999 + mcbStep : 0.00001 - mcbStep);
gl_FragDepth = mcbDepth;
}
mcb_emit(mcbColor, mcbDepth, false);
return true;
}
#endif

void main() {
// Derivatives before any branch or discard.
vec2 mcbFootprint = fwidth(texCoord0 * 128.0);
#ifndef IS_GUI
// A shader that writes gl_FragDepth anywhere must write it on every path.
gl_FragDepth = gl_FragCoord.z;
#ifndef IS_GRAYSCALE
if (mcb_fragment(mcbFootprint)) return;
#endif
#endif
mcgui_text_fragment();
}
// rpai-merge:end fragment-epilogue

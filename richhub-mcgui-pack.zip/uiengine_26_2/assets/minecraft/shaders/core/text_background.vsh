#version 330

#ifndef IS_SEE_THROUGH
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
#ifndef IS_SEE_THROUGH
in ivec2 UV2;
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
bool mcb_near(float v, float t) { return abs(v - t) < 0.0001; }
bool mcb_grid(float v) { return mcb_near(v, 0.0) || mcb_near(v, 0.5) || mcb_near(v, 1.0); }
float mcb_flag(float v) { return abs(fract(v * 16.0) - 0.375000) < 0.002 ? 1.0 : 0.0; }
// Seated cameras sit at a flagged fraction of a block along one horizontal axis and on the half-block
// grid on the other two: 0 for x, 2 for z. An overlay's camera is the player's own eye with all three
// flagged (each moved at most 1/32 of a block): 1. -1 when this camera is not seated.
int mcb_flag_axis() {
vec3 f = -CameraOffset;
if (mcb_flag(f.x) > 0.0 && mcb_flag(f.y) > 0.0 && mcb_flag(f.z) > 0.0) return 1;
if (!mcb_grid(f.y)) return -1;
if (mcb_grid(f.z) && mcb_flag(f.x) > 0.0) return 0;
if (mcb_grid(f.x) && mcb_flag(f.z) > 0.0) return 2;
return -1;
}
float mcb_seated_flag() { return mcb_flag_axis() >= 0 ? 1.0 : 0.0; }
// Only orthographic (GUI) draws: perspective projections have ProjMat[3][3] == 0.
float mcb_seated_now() { return ProjMat[3][3] != 1.0 ? 0.0 : mcb_seated_flag(); }
vec2 mcb_gui_size() { return vec2(2.0 / abs(ProjMat[0][0]), 2.0 / abs(ProjMat[1][1])); }
// Reversed depth (near 1, far 0) has ProjMat[2][2] near 0; OpenGL's classic has it near -1.
float mcb_reversed() { return ProjMat[2][2] > -0.5 ? 1.0 : 0.0; }

// See-through text has no depth test, so for a seated camera it would draw over the view, and an overlay
// keeps what lies on its panel as its own: there it moved with the pointer. None for a seated camera.
bool mcb_hidden_see_through() {
ivec3 rgb = ivec3(round(Color.rgb * 255.0));
bool pointer = (rgb.r == 254 || rgb.r == 253) && rgb.g > 0 && rgb.b > 0;
return mcb_flag_axis() >= 0 && !pointer;
}

void main() {
gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifndef IS_SEE_THROUGH
sphericalVertexDistance = fog_spherical_distance(Position);
cylindricalVertexDistance = fog_cylindrical_distance(Position);
vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
if (mcb_hidden_see_through()) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
vertexColor = Color;
#endif
}

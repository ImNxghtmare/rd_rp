#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

layout(std140) uniform SamplerInfo {
vec2 OutSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

ivec3 ov_texel(sampler2D s, int x) { return ivec3(round(texelFetch(s, ivec2(x, 0), 0).rgb * 255.0)); }

// An overlay's signature in [s]'s four bottom-left texels (text.fsh, mcb_signature): its flags plus 8, or 0
// without one; [tint], the view's tint.
int ov_signature(sampler2D s, out vec4 tint) {
tint = vec4(0.0);
ivec3 c0 = ov_texel(s, 0), c3 = ov_texel(s, 3);
if (c0 != ivec3(90, 195, 150) || c3 != ivec3(0, 0, 105)) return 0;
ivec3 c1 = ov_texel(s, 1), c2 = ov_texel(s, 2);
tint = vec4(vec3(c1), float(c2.r)) / 255.0;
return c2.g | 8;
}
uniform sampler2D InSampler;
uniform sampler2D KeptSampler;

void main() {
ivec2 at = ivec2(gl_FragCoord.xy);
vec4 tint;
int flags = ov_signature(InSampler, tint);
if (flags == 0) discard;
bool signature = at.y == 0 && at.x < 4;
float alpha = at.y == 0 && at.x < 12 ? texelFetch(InSampler, ivec2(at.x / 3, 0), 0)[at.x % 3] : 1.0;
vec4 here = texelFetch(InSampler, at, 0);
if (here.a > 0.5 && !signature) {
fragColor = vec4(here.rgb, alpha);
return;
}
vec3 live = texelFetch(InSampler, signature ? ivec2(at.x, 1) : at, 0).rgb;
if ((flags & 2) == 0) {
fragColor = vec4(live, alpha);
return;
}
vec4 kept = texelFetch(KeptSampler, at, 0);
fragColor = vec4(mix(kept.a > 0.5 ? kept.rgb : live, tint.rgb, tint.a), alpha);
}

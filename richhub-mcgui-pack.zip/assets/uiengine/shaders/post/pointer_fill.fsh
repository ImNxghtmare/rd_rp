#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
vec2 OutSize;
};

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// The first pixel from [at] along [dir] that stays, and how far it is; 0 if there is none in reach.
vec3 kept(ivec2 at, ivec2 dir, ivec2 edge, out float far) {
for (int k = 1; k <= 128; k++) {
ivec2 q = at + dir * k;
if (q != clamp(q, ivec2(0), edge)) break;
vec4 c = texelFetch(InSampler, q, 0);
if (c.a < 0.5) {
far = float(k);
return c.rgb;
}
}
far = 0.0;
return vec3(0.0);
}

void main() {
ivec2 at = ivec2(gl_FragCoord.xy);
vec4 here = texelFetch(InSampler, at, 0);
if (here.a < 0.5) {
fragColor = vec4(here.rgb, 1.0);
return;
}
ivec2 edge = textureSize(InSampler, 0) - 1;
vec3 sum = vec3(0.0);
float weights = 0.0;
for (int i = 0; i < 4; i++) {
float far;
vec3 c = kept(at, ivec2(i == 0 ? -1 : i == 1 ? 1 : 0, i == 2 ? -1 : i == 3 ? 1 : 0), edge, far);
if (far > 0.0) {
sum += c / far;
weights += 1.0 / far;
}
}
fragColor = vec4(weights > 0.0 ? sum / weights : here.rgb, 1.0);
}

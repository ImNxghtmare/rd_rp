#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

// rpai-merge:begin vertex-declarations v1
// rpai-merge:provides CameraBlockPos GlintAlpha CameraOffset GameTime ScreenSize MenuBlurRadius UseRgss
#include <minecraft:globals.glsl>
uniform sampler2D Sampler0;
// rpai-merge:end vertex-declarations
void mcgui_text_vertex() {
gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
sphericalVertexDistance = fog_spherical_distance(Position);
cylindricalVertexDistance = fog_cylindrical_distance(Position);
vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
vertexColor = Color;
#endif
texCoord0 = UV0;
}
// rpai-merge:begin vertex-vanilla v1
// #include <minecraft:dynamictransforms.glsl>
// #include <minecraft:projection.glsl>
// layout(location = 0) in vec3 Position;
// layout(location = 1) in vec4 Color;
// layout(location = 2) in vec2 UV0;
// layout(location = 2) out vec4 vertexColor;
// layout(location = 3) out vec2 texCoord0;
// rpai-merge:end vertex-vanilla
// rpai-merge:begin vertex-epilogue v1
// rpai-merge:renames main mcgui_text_vertex
bool mcb_near(float v, float t) { return abs(v - t) < 0.0001; }
bool mcb_grid(float v) { return mcb_near(v, 0.0) || mcb_near(v, 0.5) || mcb_near(v, 1.0); }
float mcb_flag(float v) { return abs(fract(v * 16.0) - 0.375000) < 0.002 ? 1.0 : 0.0; }
// Seated cameras sit at a flagged fraction of a block along one horizontal axis and on the half-block
// grid on the other two: 0 for x, 2 for z. An overlay's camera is the player's own eye with all three
// flagged (each moved at most 1/32 of a block): 1. -1 when this camera is not seated.
int mcb_flag_axis() {
vec3 f = -CameraOffset;
if (mcb_flag(f.x) > 0.0 && mcb_flag(f.y) > 0.0 && mcb_flag(f.z) > 0.0) return 1;
if (!mcb_grid(f.y)) return -1;
if (mcb_grid(f.z) && mcb_flag(f.x) > 0.0) return 0;
if (mcb_grid(f.x) && mcb_flag(f.z) > 0.0) return 2;
return -1;
}
float mcb_seated_flag() { return mcb_flag_axis() >= 0 ? 1.0 : 0.0; }
// Only orthographic (GUI) draws: perspective projections have ProjMat[3][3] == 0.
float mcb_seated_now() { return ProjMat[3][3] != 1.0 ? 0.0 : mcb_seated_flag(); }
vec2 mcb_gui_size() { return vec2(2.0 / abs(ProjMat[0][0]), 2.0 / abs(ProjMat[1][1])); }
// Reversed depth (near 1, far 0) has ProjMat[2][2] near 0; OpenGL's classic has it near -1.
float mcb_reversed() { return ProjMat[2][2] > -0.5 ? 1.0 : 0.0; }
bool mcb_in(vec2 p, vec2 a, vec2 b) { return p.x >= a.x && p.x <= b.x && p.y >= a.y && p.y <= b.y; }
bool mcb_hud(vec2 pos, vec2 size) {
float cx = floor(size.x / 2.0);
return mcb_in(pos, vec2(cx - 122.0, size.y - 24.0), vec2(cx + 122.0, size.y))
|| mcb_in(pos, vec2(cx - 92.0, size.y - 64.0), vec2(cx + 92.0, size.y - 22.0));
}
bool mcb_crosshair(vec2 pos, vec2 size) {
vec2 c = floor(size / 2.0);
return mcb_in(pos, c - 9.0, c + 9.0);
}

// ---- MC GUI hi-colour map decoder ----
// Colour -> symbol: the palette gives each symbol the colour that hashes to it (SymbolHash), so the hash
// is the whole lookup: a displacement for one of 64 buckets (128 for an odd palette), bytes four to a
// uint, read with selects alone. Never a table read by a computed index: AMD's Windows OpenGL driver
// turns one into seconds a frame and minutes of compiling (Mr Crash's RX 7700 XT, 2026-11-03: 2 FPS
// with the old table, 119 without).
uint mcb_displacements(uint i) {
uvec4 t0_0 = (i & 8u) != 0u ? uvec4(391774590u, 1662151960u, 339798529u, 53280883u) : uvec4(906494208u, 342563082u, 67249448u, 161304064u);
uvec4 t0_1 = (i & 8u) != 0u ? uvec4(2843839628u, 2316404752u, 679716608u, 3477053313u) : uvec4(25034762u, 2349278011u, 118704130u, 203165200u);
uvec4 t1_0 = (i & 4u) != 0u ? t0_1 : t0_0;
uvec2 h = (i & 2u) != 0u ? t1_0.zw : t1_0.xy;
return (i & 1u) != 0u ? h.y : h.x;
}

int mcb_symbol_of(vec3 rgb) {
uvec3 c = uvec3(round(rgb * 255.0));
uint k = (c.r << 16u) | (c.g << 8u) | c.b;
uint b = (k * 1372926309u) >> 26u;
uint s = (((k * 3137834733u) >> 24u) * 240u >> 8u) + ((mcb_displacements(b >> 2u) >> ((b & 3u) << 3u)) & 255u);
return int(s >= 240u ? s - 240u : s);
}

// Where the map being read starts in Sampler0: (0, 0) unless the texture holds many maps (mcb_texture).
ivec2 mcbBase = ivec2(0);

ivec3 mcb_fetch(ivec2 p) { return ivec3(round(texelFetch(Sampler0, mcbBase + p, 0).rgb * 255.0)); }

int mcb_symbol(ivec2 p) { return mcb_symbol_of(texelFetch(Sampler0, mcbBase + p, 0).rgb); }

// The symbols of the 2x2 block whose top-left pixel is [p] and has colour [first].
ivec4 mcb_symbols(ivec2 p, vec3 first) {
return ivec4(mcb_symbol_of(first), mcb_symbol(p + ivec2(1, 0)), mcb_symbol(p + ivec2(0, 1)), mcb_symbol(p + ivec2(1, 1)));
}

// 1 if Sampler0 is one map's own texture, 2 if it could hold many 128 x 128 maps side by side (ImmediatelyFast's
// map atlas, 2048 square by default, but a font page of 256 or 1024 is as square), 0 if it holds none.
int mcb_texture() {
ivec2 size = textureSize(Sampler0, 0);
if (size == ivec2(128, 128)) return 1;
return size.x == size.y && size.x >= 256 && (size.x & 127) == 0 ? 2 : 0;
}

bool mcb_in_texture(ivec2 base, ivec2 size) { return all(greaterThanEqual(base, ivec2(0))) && all(lessThan(base, size)); }

// Which of ours the map at mcbBase is. 0: not ours. 1: a screen. 3: the view of whoever is seated at it, each
// map carrying its place (bottom markers both the fourth). text.vsh then tells two kinds of 3 apart for
// text.fsh: 5, an overlay's signature map, and 6, a map of an overlay's panel. 7: a hover layer of a view
// (Palette.markLayer): top markers swapped too. Only for a texture mcb_texture says can hold maps.
int mcb_screen_map() {
ivec3 m0 = mcb_fetch(ivec2(0, 0)), m1 = mcb_fetch(ivec2(1, 0));
bool layer = m0 == ivec3(109,144,129) && m1 == ivec3(89,117,105);
if (!layer && (m0 != ivec3(89,117,105) || m1 != ivec3(109,144,129))) return 0;
ivec3 a = mcb_fetch(ivec2(0, 1));
ivec3 b = mcb_fetch(ivec2(1, 1));
if (layer) return a == ivec3(67,88,79) && b == ivec3(67,88,79) ? 7 : 0;
if (a == ivec3(127,167,150) && b == ivec3(67,88,79)) return 1;
if (a == ivec3(67,88,79) && b == ivec3(67,88,79)) return 3;
return 0;
}

// What someone's own view lays over the world where it is transparent (Palette.markTint): red,
// green, blue and alpha in the 2x2 block after its size.
vec4 mcb_tint() {
return vec4(float(mcb_symbol(ivec2(4, 0))), float(mcb_symbol(ivec2(5, 0))),
float(mcb_symbol(ivec2(4, 1))), float(mcb_symbol(ivec2(5, 1)))) / 239.0;
}

// How many 2x2 blocks after the marker hold data, not picture: a view's size, place and tint (2); a
// hover layer's size, place, speed, flags and two rectangles (7, the top two rows, never shown).
int mcb_info(int kind) { return kind == 7 ? 7 : kind >= 2 ? 2 : 0; }

// A 2x2 block's mean luma and its chroma, and 1 (0 for all four when it is transparent).
vec4 mcb_block(ivec2 b) {
ivec2 p = b * 2;
vec4 c00 = texelFetch(Sampler0, mcbBase + p, 0);
if (c00.a < 0.5) return vec4(0.0);
ivec4 s = mcb_symbols(p, c00.rgb);
ivec4 digit = s & 7;
return vec4(dot(vec4(s >> 3), vec4(0.25)) / 29.0, float(digit.x * 8 + digit.y - 32) / 63.0,
float(digit.z * 8 + digit.w - 32) / 63.0, 1.0);
}

// 1 if a map's data blocks (row 0, up to block [info]) are best shown as the block right of them, 0 if as
// the blocks below them: right when an edge runs between the top two block rows just past the data, so
// likely through the data too, below otherwise (nearer, and right for anything that changes along the
// row). Measured on the market pages' maps, this halves how often the fill differs visibly from the
// picture it covers, against always right or always below.
float mcb_fill_right(int info) {
vec4 a = mcb_block(ivec2(info + 1, 0)), b = mcb_block(ivec2(info + 1, 1));
if (a.w != b.w) return 1.0;
vec4 d = abs(a - b);
return d.x + 0.5 * (d.y + d.z) > 0.06 ? 1.0 : 0.0;
}

// A point at normalised device coordinates [ndc], one block in front of the camera: in the
// clip volume whatever the projection, at the same depth for every vertex (no perspective
// warp across a quad). The fragment shader sets the real depth.
vec4 mcb_flat(vec2 ndc) {
vec4 c = ProjMat * vec4(0.0, 0.0, -1.0, 1.0);
return vec4(ndc * c.w, c.z, c.w);
}

// Where the pointer the seated player's client places itself is on a view [size] pixels big: the
// view's centre plus [speed] (pixels per degree of turn) times how far the camera has turned from
// [ahead] (the axis towards the view), held inside the view. The server works the cursor out the
// same way from the rotations the client sends. [hint] is the player's own turn from [ahead] in degrees
// as the server last heard it (Views.sendTurnHint), or below -360 for none: F5's view from the front
// points the camera exactly the other way to the player (its yaw half round, its pitch negated), which
// the camera alone cannot tell from the player having turned round. The player's own look is whichever
// of the two is within a quarter turn of the hint; a hint that far out would take a whole quarter turn
// inside one round trip, and the server turns the player back at the picture's edge.
vec2 mcb_hot(vec2 size, vec3 ahead, float speed, float hint) {
vec3 right = vec3(-ahead.z, 0.0, ahead.x);
// ModelViewMat is the camera's rotation alone; its third row is minus the look direction.
vec3 look = normalize(-vec3(ModelViewMat[0][2], ModelViewMat[1][2], ModelViewMat[2][2]));
if (hint > -360.0) {
float h = radians(hint);
if (dot(look, ahead * cos(h) + right * sin(h)) < 0.0) look = -look;
}
vec2 turn = degrees(vec2(atan(dot(look, right), dot(look, ahead)), asin(clamp(-look.y, -1.0, 1.0))));
return clamp(size * 0.5 + turn * speed, vec2(0.0), size - 1.0);
}

// The pointer the seated player's client places itself, on a view [size] pixels big. Its text
// sits ahead of the camera on the flagged axis, towards the view, 0.5 + speed / 512 blocks away
// (speed in pixels per degree of turn), square to that axis: so a vertex's offset across the axis
// is the glyph's own, from its hot pixel (mcb_hot), at 128 pixels to a block.
// On an overlay (flag 1) every axis is flagged: the text's own offset says which is ahead, as the glyph
// is far smaller than its distance.
vec2 mcb_client_pointer(vec2 size) {
int flagAxis = mcb_flag_axis();
bool alongX = flagAxis == 0 || (flagAxis == 1 && abs(Position.x) > abs(Position.z));
vec3 axis = alongX ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 0.0, 1.0);
float along = dot(Position, axis);
vec3 ahead = axis * sign(along);
vec3 right = vec3(-ahead.z, 0.0, ahead.x);
// Its text's opacity is the hint (Shaders.turnHint): 128 plus the sector, anything else none.
int sector = int(round(Color.a * 255.0)) - 128;
float hint = sector >= 0 && sector < 64 ? float(sector) * (360.0 / float(64)) : -1000.0;
vec2 hot = mcb_hot(size, ahead, (abs(along) - 0.5) * 512.0, hint);
vec2 px = hot + vec2(dot(Position, right), -Position.y) * 128.0;
return vec2(px.x / size.x * 2.0 - 1.0, 1.0 - px.y / size.y * 2.0);
}

// A hover layer's rectangle in canvas pixels, [left, right) x [top, bottom), from the four 2x2 blocks'
// worth of symbols from x = [at] (Palette.markLayer): each edge two symbols, high then low.
float mcb_layer_edge(int x, int y) { return float(mcb_symbol(ivec2(x, y)) * 240 + mcb_symbol(ivec2(x + 1, y))); }
vec4 mcb_layer_rect(int at) { return vec4(mcb_layer_edge(at, 0), mcb_layer_edge(at, 1), mcb_layer_edge(at + 2, 0), mcb_layer_edge(at + 2, 1)); }
bool mcb_layer_in(vec2 p, vec4 r) { return p.x >= r.x && p.y >= r.y && p.x < r.z && p.y < r.w; }

// Whether a hover layer shows now: the client's pointer, worked out as the pointer's own from the speed,
// axis and side the layer carries ([flags]: 2 for z, 1 for facing it from the positive side), is inside
// its include rectangle and outside its exclude one.
bool mcb_layer_on(vec2 size, int flags) {
float speed = float((mcb_symbol(ivec2(4, 0)) * 240 + mcb_symbol(ivec2(5, 0))) * 240 + mcb_symbol(ivec2(4, 1))) / 32768.0;
vec3 axis = (flags & 2) == 0 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 0.0, 1.0);
// The quarter-turn hint (Palette.markLayer, Shaders.turnQuarter): 0 for none.
int quarter = mcb_symbol(ivec2(14, 1));
vec2 hot = mcb_hot(size, (flags & 1) == 1 ? -axis : axis, speed, quarter > 0 ? float(quarter - 1) * 90.0 : -1000.0);
return mcb_layer_in(hot, mcb_layer_rect(6)) && !mcb_layer_in(hot, mcb_layer_rect(10));
}

// Which of our maps this vertex's quad shows (mcb_screen_map), with mcbBase set to where that map starts in
// Sampler0 and mcbUv to which of its corners this vertex is. ImmediatelyFast (a client mod) draws every
// map from one big texture by default ("map_atlas_generation"), each 128 x 128 square of it a map, the
// quad's texture coordinates that square's: a corner there is a corner of up to four maps. A view's maps
// all hang in the camera's block, on its floor or ceiling (MapWall.Stack), so which corner of the block a
// vertex is says which of its map it is: u runs along x on both, v along z on the floor and against it
// on the ceiling (ItemFrameRenderer, rotation 0). Any other map of ours in such a texture (a wall's)
// is -1: drawn where it hangs, it needs nothing from here, and text.fsh finds it pixel by pixel.
vec2 mcbUv;
int mcb_locate() {
mcbUv = UV0;
int textureKind = mcb_texture();
if (textureKind != 2) return textureKind == 1 ? mcb_screen_map() : 0;
ivec2 size = textureSize(Sampler0, 0);
vec2 at = UV0 * vec2(size) / 128.0, k = round(at);
if (any(greaterThan(abs(at - k), vec2(0.001)))) return 0;
vec3 rel = Position - CameraOffset;
if (mcb_flag_axis() >= 0 && all(greaterThan(rel, vec3(-0.01))) && all(lessThan(rel, vec3(1.01)))) {
vec2 corner = vec2(rel.x > 0.5 ? 1.0 : 0.0, (rel.y < 0.5) == (rel.z > 0.5) ? 1.0 : 0.0);
mcbBase = ivec2(k - corner) * 128;
if (mcb_in_texture(mcbBase, size)) {
int kind = mcb_screen_map();
if (kind >= 3) {
mcbUv = corner;
return kind;
}
}
}
mcbBase = ivec2(0);
return 0;
}

// The tint's four symbols (Palette.markTint): red, green, blue and alpha in the 2x2 block after the view's size.
ivec4 mcb_tint_symbols() {
return ivec4(mcb_symbol(ivec2(4, 0)), mcb_symbol(ivec2(5, 0)), mcb_symbol(ivec2(4, 1)), mcb_symbol(ivec2(5, 1)));
}

// GUI text: the XP level over the hotbar is hidden while seated, like the rest of the HUD (position_tex_color).
void mcb_gui_vertex() {
if (mcb_seated_now() > 0.5) {
vec2 mcbPos = (ModelViewMat * vec4(Position, 1.0)).xy;
vec2 mcbSize = mcb_gui_size();
float cx = floor(mcbSize.x / 2.0);
if (mcb_in(mcbPos, vec2(cx - 40.0, mcbSize.y - 40.0), vec2(cx + 40.0, mcbSize.y - 22.0))) vertexColor.a = 0.0;
}
}

void mcb_world_vertex() {
float mcbSeated = mcb_seated_flag();
bool mcbRev = mcb_reversed() > 0.5;
int mcbMap = 0;
#ifndef IS_GRAYSCALE
mcbMap = mcb_locate();
#endif
int mcbKind = mcbMap;
int mcbPointer = 0;
int mcbPriority = 0;
if (mcbSeated > 0.5) {
ivec3 mcbRgb = ivec3(round(Color.rgb * 255.0));
vec2 mcbGrid = vec2(0.0);
if (mcbRgb.r == 254 && mcbRgb.g > 0 && mcbRgb.b > 0) {
// The pointer: text in the pointer's red, its view's columns and rows in green and blue. Drawn white.
mcbPointer = 1;
mcbGrid = vec2(mcbRgb.gb);
// It lies ahead of the camera, a level mannequin (Views.spawnCamera). Behind it, F5's view
// from the front has turned that camera exactly half round about the vertical: the pointer is
// turned with it, which puts it where the camera facing the picture would see it.
vec3 mcbLook = -vec3(ModelViewMat[0][2], ModelViewMat[1][2], ModelViewMat[2][2]);
if (dot(Position, mcbLook) < 0.0) gl_Position = ProjMat * ModelViewMat * vec4(-Position.x, Position.y, -Position.z, 1.0);
} else if (mcbRgb.r == 253 && mcbRgb.g > 0 && mcbRgb.b > 0) {
// The pointer this client places itself, from where the camera looks.
mcbPointer = 2;
gl_Position = mcb_flat(mcb_client_pointer(vec2(mcbRgb.gb) * 128.0));
} else if (mcbMap == 3) {
// Their own view: each map carries its view's columns and rows and its own column and
// row, and goes to its place in the window by those and its corner (the map quad's
// texture coordinates are exactly 0 and 1), wherever its frame is and wherever the
// camera looks. An overlay sends only the maps its panel covers, so nothing is drawn
// round them.
vec2 mcbViewGrid = vec2(float(mcb_symbol(ivec2(2, 0))), float(mcb_symbol(ivec2(3, 0))));
vec2 mcbTile = vec2(float(mcb_symbol(ivec2(2, 1))), float(mcb_symbol(ivec2(3, 1))));
if (mcbTile == vec2(239.0)) {
// An overlay's signature map (Palette.markSignature): over the window's four
// bottom-left pixels, which text.fsh writes for the post effect to read.
mcbKind = 5;
gl_Position = mcb_flat(vec2(-1.0) + vec2(mcbUv.x * 8.0, (1.0 - mcbUv.y) * 2.0) / ScreenSize);
} else {
if (mcb_flag_axis() == 1) mcbKind = 6;
vec2 mcbAt = (mcbTile + mcbUv) / mcbViewGrid;
gl_Position = mcb_flat(vec2(mcbAt.x * 2.0 - 1.0, 1.0 - mcbAt.y * 2.0));
}
} else if (mcbMap == 7) {
// A hover layer (Palette.markLayer): placed by the canvas pixel its third row starts at, 128
// canvas pixels to its side, but only while this client's pointer is over its element, and
// then with its priority plus one, for text.fsh's depth. Otherwise it goes behind the far
// plane, below.
int mcbFlags = mcb_symbol(ivec2(5, 1));
vec2 mcbViewGrid = vec2(float(mcb_symbol(ivec2(2, 0))), float(mcb_symbol(ivec2(3, 0))));
if (mcb_layer_on(mcbViewGrid * 128.0, mcbFlags)) {
mcbPriority = (mcbFlags >> 2) + 1;
vec2 mcbOrigin = vec2(mcb_layer_edge(2, 1), mcb_layer_edge(14, 0) - 2.0);
vec2 mcbAt = (mcbOrigin + mcbUv * 128.0) / (mcbViewGrid * 128.0);
gl_Position = mcb_flat(vec2(mcbAt.x * 2.0 - 1.0, 1.0 - mcbAt.y * 2.0));
}
}
// Both fill the window whatever its shape and whatever the player's FOV. The picture is centred
// on the camera's axis and square to it, so how far a vertex is from that axis, in blocks, as a
// fraction of half the picture's size, is where it goes in the window.
if (mcbGrid.x > 0.0 && mcbGrid.y > 0.0) {
vec2 mcbBlocks = gl_Position.xy / vec2(ProjMat[0][0], ProjMat[1][1]);
gl_Position.xy = mcbBlocks / (mcbGrid * 0.5) * gl_Position.w;
}
}
// A hover layer not shown, or not seated: every vertex behind the far plane, so it draws no pixel.
if (mcbMap == 7 && mcbPriority == 0) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
// A view's own maps (3 and up) show only to its seated camera. They lie on the floor or ceiling of
// the camera's block (MapWall.Stack), so a camera not flagged (the frames there a moment before the
// eye is, or a moment after it is put back) drew them where they lie: pieces of the picture, huge,
// round the camera.
if (mcbMap >= 3 && mcbSeated < 0.5) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
// A view's notice for players whose shaders replace these (Shaders.NOTICE_RGB, NOTICE_ALPHA): never drawn here.
if (ivec4(round(Color * 255.0)) == ivec4(252, 224, 74, 254)) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
#ifdef IS_SEE_THROUGH
// See-through text (text displays with see_through, name tags' faint pass) is drawn with no depth
// test, so over a seated camera's view too, and an overlay keeps what lies on its panel as its own:
// there it moved with the pointer. None for a seated camera (its pointer is not see-through).
if (mcbSeated > 0.5 && mcbPointer == 0) gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
#endif
if (mcbPointer > 0) {
// Drawn white under whatever light the vertex shader before ours gave the text (its red over the
// text's own), at the server pointer's opacity; the client pointer's opacity is its turn hint.
float mcbLight = clamp(vertexColor.r / max(Color.r, 0.004), 0.0, 1.0);
float mcbAlpha = mcbPointer == 1 ? Color.a : 1.0;
vertexColor = vec4(vec3(mcbLight), 16.0 * float(mcbPointer) + (mcbRev ? 8.0 : 0.0) + mcbAlpha);
} else if (mcbMap >= 3) {
bool mcbFill = mcbMap != 7 && mcb_fill_right(mcb_info(mcbMap)) > 0.5;
ivec4 mcbTint = mcbMap != 7 ? mcb_tint_symbols() : ivec4(0);
int mcbRed = mcbKind | (mcbFill ? 8 : 0) | (mcbPriority << 4) | (mcbRev ? 1024 : 0);
vertexColor = vec4(float(mcbRed), float(mcbBase.x / 128 + 64 * (mcbBase.y / 128)),
float(mcbTint.x * 256 + mcbTint.y), 65536.0 + float(mcbTint.z * 256 + mcbTint.w));
}
}

void main() {
mcgui_text_vertex();
#ifdef IS_GUI
mcb_gui_vertex();
#else
mcb_world_vertex();
#endif
}
// rpai-merge:end vertex-epilogue

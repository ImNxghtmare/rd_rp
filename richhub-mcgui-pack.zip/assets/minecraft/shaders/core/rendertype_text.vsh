#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Match SelectorLayout / selector_pack.py: late-packet prediction cannot change the selected card.
vec2 constrainPointer(vec2 point, vec2 target) {
    const vec4 cards[7] = vec4[7](
        vec4(4,54,157,139), vec4(162,54,315,94), vec4(162,99,315,139),
        vec4(4,144,105,186), vec4(110,144,211,186), vec4(216,144,315,186),
        vec4(246,191,315,213));
    for (int i = 0; i < 7; i++) {
        if (all(greaterThanEqual(target, cards[i].xy)) && all(lessThanEqual(target, cards[i].zw))) {
            point = clamp(point, cards[i].xy, cards[i].zw);
            break;
        }
    }
    return clamp(point, vec2(0), vec2(312,214));
}

// Only the selector fonts use these reserved off-screen ascent bands.
// Colours remain unrestricted for all ordinary text, chat, holograms and ModelEngine.
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    if (ProjMat[3][3] < 0.5) return; // World text is never an overlay.
    vec2 ndc = gl_Position.xy / gl_Position.w;
    float guiWidth = 2.0 / ProjMat[0][0];
    float guiHeight = -2.0 / ProjMat[1][1];
    float fromTop = (1.0 - ndc.y) * guiHeight * 0.5;
    // Projection round-trips can put an exact top edge a fraction below its sentinel.
    bool art = fromTop >= 4095.0 && fromTop <= 4353.0;
    bool pointer = fromTop >= 8191.0 && fromTop <= 8449.0;
    if (!art && !pointer) return;

    vec2 logical = vec2(ndc.x * guiWidth * 0.5 + 160.0,
                        fromTop - (pointer ? 8192.0 : 4096.0));
    if (pointer) {
        ivec3 rgb = ivec3(round(Color.rgb * 255.0));
        int data = (rgb.r << 16) | (rgb.g << 8) | rgb.b;
        int kind = (data >> 22) & 3;
        float stamp = float((data >> 17) & 31);
        vec2 target = vec2(float(data & 511), float((data >> 9) & 255));
        float elapsed = mod(GameTime * 24000.0 - stamp + 16.0, 32.0) - 16.0;
        // Minecraft emits each text quad TL, BL, BR, TR. All four vertices move together.
        int corner = gl_VertexID & 3;
        vec2 extent = vec2(corner >= 2 ? 8.0 : 0.0,
                           corner == 1 || corner == 2 ? 10.0 : 0.0);
        // One glyph is always visible: full-tick forward motion, half-tick correction,
        // or an idle hold. No future-tick buffer and no overlapping cursor trails.
        float duration = kind == 0 ? 1.0 : 0.5;
        float progress = kind == 3 ? 1.0 : clamp(elapsed / duration, 0.0, 1.0);
        vec2 start = logical - extent;
        vec2 point = mix(start, target, progress);
        if (kind == 0 && elapsed > 1.0) {
            vec2 delta = target - start;
            float extra = min(clamp(elapsed - 1.0, 0.0, 1.0), 12.0 / max(0.001, length(delta)));
            point = constrainPointer(point + delta * extra, target);
        }
        logical = clamp(point, vec2(0), vec2(312,214)) + extent;
        vertexColor = vec4(1.0);
    }

    float scale = min(1.25, min(guiWidth * 0.78 / 320.0, guiHeight * 0.72 / 224.0));
    float top = (guiHeight - 224.0 * scale) * 0.10;
    vec2 screen = vec2(guiWidth * 0.5 + (logical.x - 160.0) * scale,
                       top + logical.y * scale);
    gl_Position.xy = vec2(screen.x * 2.0 / guiWidth - 1.0,
                         1.0 - screen.y * 2.0 / guiHeight) * gl_Position.w;
    sphericalVertexDistance = 0.0;
    cylindricalVertexDistance = 0.0;
}
